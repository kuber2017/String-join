public class Main{  
public static void main(String args[]){  

String  join = String.join("-", "hello", "world ");
System.out.println(join);
}
}